// Netlify Function: netlify/functions/gemini.js
// يربط واجهة "المعلم الذكي" بمفتاح GEMINI_API_KEY المحفوظ بأمان في Netlify

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "مفتاح GEMINI_API_KEY غير مضبوط في إعدادات Netlify."
      })
    };
  }

  try {
    const body = JSON.parse(event.body || "{}");
    const message = (body.message || "").trim();
    const history = Array.isArray(body.history) ? body.history : [];
    const studentName = (body.studentName || "").trim();
    const studentGrade = (body.studentGrade || "").trim();

    if (!message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "الرجاء كتابة سؤالك أولاً." })
      };
    }

    const systemText = [
      "أنت 'المعلم الذكي' في منصة 'نبراس المعرفة' التعليمية.",
      "مهمتك مساعدة الطلاب في فهم دروسهم وحل المسائل خطوة بخطوة وتلخيص المناهج (مع مراعاة المنهج السوداني متى كان ذلك مناسباً).",
      studentName ? `اسم الطالب الحالي: ${studentName}.` : "",
      studentGrade ? `الصف الدراسي للطالب: ${studentGrade}.` : "",
      "أجب بلغة عربية واضحة، مشجعة، ومنظمة بنقاط قصيرة وأمثلة عملية. لا تُطِل بلا داعٍ، وإذا طلب الطالب اختباراً فضع له أسئلة واضحة وانتظر إجابته أو صحح له."
    ].filter(Boolean).join(" ");

    const contents = [];
    for (const item of history.slice(-10)) {
      if (item && item.text && (item.role === "user" || item.role === "model")) {
        contents.push({
          role: item.role,
          parts: [{ text: String(item.text) }]
        });
      }
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`;

    const apiRes = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: {
          parts: [{ text: systemText }]
        },
        contents: contents,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1200
        }
      })
    });

    const apiData = await apiRes.json();

    if (!apiRes.ok) {
      const errMsg = apiData?.error?.message || "حدث خطأ من خدمة Gemini API.";
      return {
        statusCode: apiRes.status,
        headers,
        body: JSON.stringify({ error: errMsg })
      };
    }

    const reply =
      apiData?.candidates?.[0]?.content?.parts
        ?.map((p) => p.text || "")
        .join("")
        .trim() || "لم يتم استلام رد من المعلم الذكي، حاول مجدداً.";

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "خطأ داخلي في الخادم: " + err.message })
    };
  }
};
